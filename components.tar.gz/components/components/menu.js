/*
  The menu  


*/
var Menu =Object.extends(Context,(function(domId, options)
{
  var __options = Object.copy({

  }, options);
  Context.call(this, domId, __options);
  if(this.options){
  	 this.addClass("menu");
  }
 
}));


